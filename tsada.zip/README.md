# Technical school Ada

Made with ❤ by Kovács Árpád.