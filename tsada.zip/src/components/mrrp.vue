<template>
<div class="mx-auto">
    <img src="@a/profileBanner_dzuderbbkat91.webp" />óó
</div>
</template>
<script>
</script>