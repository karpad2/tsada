<template>
  <section class="text-gray-600 min-h-screen">
    <div class="container px-5 py-20 mx-auto bg-slate-100/30 dark:bg-slate-300/30">
      <div class="flex flex-wrap w-full mb-20">
        <div class="lg:w-1/3 w-full mb-6 lg:mb-0">
          <h1 id="render_title" class="sm:text-3xl text-2xl font-medium mb-2 text-gray-900 dark:text-white">{{ t('workers') }}</h1>
          <div class="h-1 w-20 bg-sky-500 rounded"></div>
        </div>
      </div>

      <div v-if="loaded">
        <div
          v-for="(role, index) in visibleRoles"
          :key="role.id"
          class="w-full mb-8"
        >
          <h2 class="sm:text-2xl text-lg font-medium mb-3 text-gray-900 dark:text-white">{{ role.role }}</h2>
          <v-data-table
            :height="400"
            :headers="headers"
            :items="role.workers"
            :items-per-page="-1"
            hide-default-footer
          >
            <template v-slot:item.img="{ item }">
              <img v-lazy="item.img" class="object-cover w-20 h-20 rounded" />
            </template>
            <template v-slot:item.edit="{ item }">
              <router-link :to="`/admin/worker/${item.id}`">
                <i class="pi pi-user-edit text-4xl text-gray-600 hover:text-sky-500 transition-colors"></i>
              </router-link>
            </template>
          </v-data-table>

          <v-btn
            v-if="admin"
            @click="addNewWorker(role.id)"
            class="mt-5 bg-sky-500 text-white hover:bg-sky-600"
          >
            {{ t('add_new_worker_in_that_category') }}
          </v-btn>
        </div>

        <div ref="loadMoreTrigger" class="h-px"></div>
      </div>

      <Loading v-else />
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, onUpdated, onUnmounted } from 'vue';
import { useI18n } from 'vue-i18n';
import { Client, Databases, ID, Storage, Query } from 'appwrite';
import { appw, config } from '@/appwrite';
import { convertifserbian } from '@/lang';
import { useLoadingStore } from '@/stores/loading';
import gsap from 'gsap';
import Loading from '@/components/Loading.vue';

interface Worker {
  id: string;
  name: string;
  contact: string;
  img: string;
}

interface Role {
  id: string;
  role: string;
  workers: Worker[];
}

export default defineComponent({
  name: 'Workers',
  components: { Loading },
  setup() {
    const { t } = useI18n();
    const visibleRoles = ref<Role[]>([]);
    const allRoles = ref<Role[]>([]);
    const loadCount = 3;
    const loadIndex = ref(0);
    const loadMoreTrigger = ref<HTMLElement | null>(null);
    const headers = ref([]);
    const admin = ref(false);
    const loaded = ref(false);
    const loadingStore = useLoadingStore();
    let observer: IntersectionObserver | null = null;

    const loadMoreRoles = () => {
      if (loadIndex.value >= allRoles.value.length) return;
      const nextChunk = allRoles.value.slice(loadIndex.value, loadIndex.value + loadCount);
      visibleRoles.value.push(...nextChunk);
      loadIndex.value += loadCount;
    };

    const addNewWorker = async (roleId: string) => {
      try {
        const database = new Databases(appw);
        const doc = await database.createDocument(
          config.website_db,
          config.workers,
          ID.unique(),
          { roles: roleId }
        );
        window.location.href = `/admin/worker/${doc.$id}`;
      } catch (error) {
        console.error('Failed to create new worker:', error);
      }
    };

    const loadWorkers = async () => {
      try {
        const database = new Databases(appw);
        const storage = new Storage(appw);
        const local = loadingStore.language;
        const missingPicture = storage.getFileView(config.website_images, config.missing_worker_picture).href;

        const roleDocs = await database.listDocuments(config.website_db, config.roles_db, [
          Query.orderAsc('listasorrend'),
        ]);

        const rolesPromises = roleDocs.documents.map(async (role) => {
          const workersDocs = await database.listDocuments(config.website_db, config.workers, [
            Query.select(['worker_name_hu', 'worker_name_rs', 'contact', 'worker_img', '$id']),
            Query.equal('roles', [role.$id]),
          ]);

          const roleName =
            local === 'en'
              ? role.role_en
              : local === 'hu'
              ? role.role_hu
              : convertifserbian(role.role_rs);

          const workers: Worker[] = workersDocs.documents.map((worker) => ({
            id: worker.$id,
            name: local === 'rs' || local === 'sr' ? convertifserbian(worker.worker_name_rs) : worker.worker_name_hu,
            contact: worker.contact,
            img: worker.worker_img ? storage.getFileView(config.website_images, worker.worker_img).href : missingPicture,
          }));

          return { id: role.$id, role: roleName, workers };
        });

        allRoles.value = await Promise.all(rolesPromises);
        loaded.value = true;
        loadMoreRoles();
      } catch (error) {
        console.error('Failed to load workers:', error);
        loaded.value = false;
      }
    };

    const setupIntersectionObserver = () => {
      if (loadMoreTrigger.value && !observer) {
        observer = new IntersectionObserver(
          (entries) => {
            if (entries[0].isIntersecting) {
              loadMoreRoles();
            }
          },
          { rootMargin: '100px' }
        );
        observer.observe(loadMoreTrigger.value);
      }
    };

    onMounted(() => {
      admin.value = loadingStore.userLoggedin;
      document.title = t('workers');

      headers.value = admin.value
        ? [
            { title: t('name'), align: 'start', sortable: false, key: 'name', width: '200px' },
            { title: t('contact'), align: 'start', key: 'contact', width: '300px' },
            { title: t('photo'), align: 'start', key: 'img', width: '200px' },
            { title: t('edit'), align: 'start', key: 'edit', width: '100px' },
          ]
        : [
            { title: t('name'), align: 'start', sortable: false, key: 'name', width: '200px' },
            { title: t('contact'), align: 'start', key: 'contact', width: '300px' },
            { title: t('photo'), align: 'start', key: 'img', width: '200px' },
          ];

      gsap.fromTo('#render_title', { opacity: 0, x: '50%' }, { duration: 1.5, opacity: 1, x: 0 });
      loadWorkers();
    });

    onUpdated(() => {
      setupIntersectionObserver();
    });

    onUnmounted(() => {
      if (observer) {
        observer.disconnect();
        observer = null;
      }
    });

    return {
      visibleRoles,
      loadMoreTrigger,
      headers,
      admin,
      loaded,
      addNewWorker,
      t,
    };
  },
});
</script>

<style scoped>
.pi-user-edit {
  @apply text-4xl text-gray-600 hover:text-sky-500 transition-colors;
}
</style>