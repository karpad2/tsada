<template>
  <section class="text-gray-600 min-h-screen">
    <div class="container px-5 py-20 mx-auto bg-slate-100/30 dark:bg-slate-300/30">
      <div class="flex flex-wrap w-full mb-20">
        <div class="lg:w-1/3 w-full mb-6 lg:mb-0">
          <h1
            id="render_title"
            class="sm:text-3xl text-2xl font-medium title-font mb-2 text-gray-900 dark:text-white"
          >
            {{ $t('teachers_receiving_hour') }}
          </h1>
          <div class="h-1 w-20 bg-sky-500 rounded"></div>
        </div>
      </div>

      <div v-if="loaded" v-for="role in roles" :key="role.id" class="popups">
        <h1 class="sm:text-2xl text-sm font-medium mb-3 text-gray-900 dark:text-white">
          {{ role.role }}
        </h1>
        <v-data-table :headers="headers" :items="role.workers" height="400">
          <template #bottom></template>
        </v-data-table>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { Databases, Storage, ID, Query } from 'appwrite';
import { appw, config } from '@/appwrite';
import { convertifserbian } from '@/lang';
import { useLoadingStore } from '@/stores/loading';
import gsap from 'gsap';

interface Worker {
  id: string;
  name: string;
  contact: string;
  img: string;
  p_receiving_hour: string;
  u_receiving_hour: string;
}

interface Role {
  id: string;
  role: string;
  workers: Worker[];
}

export default defineComponent({
  name: 'Workers',
  data() {
    return {
      workers: [], // Kept as it was in original, though unused
      roles: [] as Role[],
      colDefs: [], // Kept as it was in original, though unused
      loaded: false,
      headers: [] as any[],
      admin: false,
    };
  },
  async mounted() {
    const loadingStore = useLoadingStore();
    this.admin = loadingStore.userLoggedin;
    document.title = this.$t('teachers_receiving_hour');

    // Optimized animation with ease
    gsap.fromTo(
      '#render_title',
      { opacity: 0, x: 50 },
      { duration: 1, opacity: 1, x: 0, ease: 'power2.out' }
    );

    this.headers = [
      { title: this.$t('name'), align: 'start', sortable: false, key: 'name', width: '200px' },
      { title: this.$t('p_receiving_hour'), align: 'start', key: 'p_receiving_hour', width: '300px' },
      { title: this.$t('u_receiving_hour'), align: 'start', key: 'u_receiving_hour', width: '300px' },
    ];

    try {
      await this.loadWorkers();
      // Optimized animation with stagger
      gsap.fromTo(
        '.popups',
        { opacity: 0, y: 20 },
        { duration: 0.8, opacity: 1, y: 0, stagger: 0.2, ease: 'power2.out' }
      );
    } catch (error) {
      console.error('Failed to load workers:', error);
    }
  },
  methods: {
    async new_stuff(roleId: string) {
      try {
        const database = new Databases(appw);
        const doc = await database.createDocument(config.website_db, config.workers, ID.unique(), {
          roles: roleId,
        });
        await this.$router.push(`/admin/worker/${doc.$id}`);
      } catch (error) {
        console.error('Failed to create new worker:', error);
      }
    },
    async loadWorkers() {
      const loadingStore = useLoadingStore();
      const database = new Databases(appw);
      const storage = new Storage(appw);
      const local = loadingStore.language;

      try {
        const missingPicture = storage.getFileView(config.website_images, config.missing_worker_picture).href;
        const rolesRes = await database.listDocuments(config.website_db, config.roles_db, [
          Query.orderAsc('listasorrend'),
          Query.equal('has_receiving_hour', true),
        ]);

        this.roles = [];
        for (const roleDoc of rolesRes.documents) {
          const roleId = roleDoc.$id;
          let roleName = '';
          if (local === 'en') roleName = roleDoc.role_en;
          else if (local === 'hu') roleName = roleDoc.role_hu;
          else if (local === 'rs' || local === 'sr') roleName = convertifserbian(roleDoc.role_rs);

          const workersRes = await database.listDocuments(config.website_db, config.workers, [
            Query.equal('roles', [roleId]),
          ]);

          const workers = workersRes.documents.map((worker) => ({
            id: worker.$id,
            name: local === 'en' || local === 'hu' ? worker.worker_name_hu : convertifserbian(worker.worker_name_rs),
            contact: worker.contact || '',
            img: worker.worker_img
              ? storage.getFileView(config.website_images, worker.worker_img).href
              : missingPicture,
            p_receiving_hour: worker.p_receiving_hour || '---',
            u_receiving_hour: worker.u_receiving_hour || '---',
          }));

          this.roles.push({ id: roleId, role: roleName, workers });
        }
        this.loaded = true;
      } catch (error) {
        console.error('Error loading workers:', error);
        this.loaded = true; // Prevent infinite loading
        throw error;
      }
    },
  },
});
</script>

<style scoped>
.popups {
  transition: all 0.3s ease-in-out;
}
</style>