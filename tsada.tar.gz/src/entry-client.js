import { createApp } from './main'

const { app } = createApp()

app.mount('#app')